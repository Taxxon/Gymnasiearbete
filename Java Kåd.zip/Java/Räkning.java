
public class Räkning{
	public static void main(String[] args) {

		try{
			Thread.sleep(10000);
		} catch(InterruptedException ex) {

		}
		long start = 0;
		long runs = 1000000000;
		for(int i = -100000; i < runs; i++){
			if(i == 0){
				start = System.currentTimeMillis();
			}
		}
		long time = System.currentTimeMillis() - start;
		System.out.println("Det tog: " + time);
		try{
			Thread.sleep(10000);
		} catch(InterruptedException ex) {

		}
	}
}