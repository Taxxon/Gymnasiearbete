
import java.util.Arrays;

public class Räkning_med_primtal{
	public static void main(String[] args) {
		int primes = 0;

		try{
			Thread.sleep(10000);
		} catch(InterruptedException ex) {

		}
		long start = 0;
		long runs = 100009;
		for(int i = -100000; i < runs; i++){
			if(i == 0){
				start = System.currentTimeMillis();
			}
			if (i >= 0) {
				for (int z = 2; z < i; z ++){
					if (i % z == 0) {
						primes++;
					}
				}
			}
		}
		long time = System.currentTimeMillis() - start;
		System.out.println("Det tog: " + time);
		try{
			Thread.sleep(10000);
		} catch(InterruptedException ex) {

		}
	}
}